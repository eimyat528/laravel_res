<?php
    return[
        'order_status' =>[
            'new' =>1,
            'processing' =>2,
            'cancel' =>3,
            'ready'=>4,
            'done'=>5,
        ]
    ]
?>